# content-type-identifier
Library that helps identify what type of content is for a given file
